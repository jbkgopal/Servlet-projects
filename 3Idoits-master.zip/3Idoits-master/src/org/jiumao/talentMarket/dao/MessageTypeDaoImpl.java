package org.jiumao.talentMarket.dao;

import org.jiumao.talentMarket.domain.MessageType;

import base.BaseDaoImpl;

public class MessageTypeDaoImpl extends BaseDaoImpl<MessageType> implements MessageTypeDao{

}
