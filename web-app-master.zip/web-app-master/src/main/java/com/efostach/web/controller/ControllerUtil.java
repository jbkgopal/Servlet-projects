package com.efostach.web.controller;

public class ControllerUtil {

    public static String EMPTY_INPUT_VALUE_WARN_MSG = "Please, input value.";
    public static String OBJ_NOT_FOUND_WARN_MSG = "Object is not found.";
    public static String REF_OBJ_NOT_EXISTS_WARN_MSG = "Input referenced object doesn't exist.";
}