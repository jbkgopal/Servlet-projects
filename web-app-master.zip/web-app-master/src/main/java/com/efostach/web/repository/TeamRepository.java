package com.efostach.web.repository;

import com.efostach.web.model.Team;

public interface TeamRepository extends GenericRpository<Team, Integer> {

}
