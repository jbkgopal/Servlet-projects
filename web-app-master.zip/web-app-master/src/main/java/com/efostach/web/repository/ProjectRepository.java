package com.efostach.web.repository;

import com.efostach.web.model.Project;

public interface ProjectRepository extends GenericRpository<Project, Integer>  {

}