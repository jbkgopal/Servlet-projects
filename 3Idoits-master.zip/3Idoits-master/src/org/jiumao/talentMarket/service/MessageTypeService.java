package org.jiumao.talentMarket.service;

import org.jiumao.talentMarket.domain.MessageType;

import base.BaseService;

public interface MessageTypeService extends BaseService<MessageType> {

}
