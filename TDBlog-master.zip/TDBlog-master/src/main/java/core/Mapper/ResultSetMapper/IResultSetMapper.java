package core.Mapper.ResultSetMapper;

import java.sql.ResultSet;

import core.Mapper.IMapper;

public interface IResultSetMapper<T> extends IMapper<ResultSet, T> {

}