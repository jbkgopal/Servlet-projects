function divHide()
{
	var ele=document.getElementById("div02");
	ele.style.display="none";
var ele=document.getElementById("div01");
if(ele.style.display=="none")
	{
	
	ele.style.display="block";
	}
else
	ele.style.display="none";
}
function divHide2()
{
	var ele=document.getElementById("div01");
	ele.style.display="none";
	var ele=document.getElementById("div02");
	
	if(ele.style.display=="none")
		{
		
		ele.style.display="block";
		}
	else
		ele.style.display="none";	
}/**
 * 
 */