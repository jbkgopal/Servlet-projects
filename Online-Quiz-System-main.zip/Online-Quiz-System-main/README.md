# OES-JDBC-Servlet-JSP
An online quiz system implemented with Advanced java

### Please note

1. It is just a dummy project, not a complete one
2. Did not concentrated on program structures and hierrarchies
3. Not much work done in database schemas

### Implementation

1. Database: MySQL
2. Server:   Tomcat 7
3. Technologies included:   JDBC, Servlet JSP
