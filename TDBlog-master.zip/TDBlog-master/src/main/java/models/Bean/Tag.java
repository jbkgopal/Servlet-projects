package models.Bean;

public class Tag {
	private String ID;
	private String name;
	
	public String getID() {
		return ID;
	}
	public String getName() {
		return name;
	}
	
	public void setID(String iD) {
		ID = iD;
	}
	public void setName(String name) {
		this.name = name;
	}
}
