package org.jiumao.talentMarket.service;

import org.jiumao.talentMarket.domain.MessageType;

import base.BaseServiceImpl;

public class MessageTypeServiceImpl extends BaseServiceImpl<MessageType> implements MessageTypeService {

}
