package ensiastjob.model;

public enum Role {
    ADMIN,
    STUDENT,
    COMPANY
}
