package beans;

public class DoctorBean {
	private String dnum;
	private String dname;
	private String dsex;
	private int dage;
	private String dtel;
	private String dtitle;
	private String dpost;
	private String dedu;
	private String ddepartment;
	private String dcon;
	public String getDnum() {
		return dnum;
	}
	public void setDnum(String dnum) {
		this.dnum = dnum;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDsex() {
		return dsex;
	}
	public void setDsex(String dsex) {
		this.dsex = dsex;
	}
	public int getDage() {
		return dage;
	}
	public void setDage(int dage) {
		this.dage = dage;
	}
	public String getDtel() {
		return dtel;
	}
	public void setDtel(String dtel) {
		this.dtel = dtel;
	}
	public String getDtitle() {
		return dtitle;
	}
	public void setDtitle(String dtitle) {
		this.dtitle = dtitle;
	}
	public String getDpost() {
		return dpost;
	}
	public void setDpost(String dpost) {
		this.dpost = dpost;
	}
	public String getDedu() {
		return dedu;
	}
	public void setDedu(String dedu) {
		this.dedu = dedu;
	}
	public String getDdepartment() {
		return ddepartment;
	}
	public void setDdepartment(String ddepartment) {
		this.ddepartment = ddepartment;
	}
	public String getDcon() {
		return dcon;
	}
	public void setDcon(String dcon) {
		this.dcon = dcon;
	}
	
}
