package beans;
/** 
* @author PC
*/
public class BackendManage_UserBean {
	
	private String dnum;
	private String dname;
	private String dsex;
	private int dage;
	private String dtel;
	private String dtitle;
	private String dpost;
	private String dedu;
	private String ddepartment;
	private String dcon;
	
	private String pnum;
	private String pname;
	private String psex;
	private int page;
	private String pid;
	private String ptel;
	private String ppsd;
	private String pinfor;
	private String pmdad;
	
	private int anum;
	private String yytime;
	private String jztime;
	private int astate;
	private int atype;
	
	private String drnum;
	private String drname;
	private float drprice;
	private String drtype;
	
	private int tmnum;
	private int drquantity;
	private int tmstate;
	

	private String mtnum;
	private String mtname;
	private float mtprice;
	private String mtplace;
	
	private int mtenum;
	private String mtetime;
	public String getDnum() {
		return dnum;
	}
	public void setDnum(String dnum) {
		this.dnum = dnum;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDsex() {
		return dsex;
	}
	public void setDsex(String dsex) {
		this.dsex = dsex;
	}
	public int getDage() {
		return dage;
	}
	public void setDage(int dage) {
		this.dage = dage;
	}
	public String getDtel() {
		return dtel;
	}
	public void setDtel(String dtel) {
		this.dtel = dtel;
	}
	public String getDtitle() {
		return dtitle;
	}
	public void setDtitle(String dtitle) {
		this.dtitle = dtitle;
	}
	public String getDpost() {
		return dpost;
	}
	public void setDpost(String dpost) {
		this.dpost = dpost;
	}
	public String getDedu() {
		return dedu;
	}
	public void setDedu(String dedu) {
		this.dedu = dedu;
	}
	public String getDdepartment() {
		return ddepartment;
	}
	public void setDdepartment(String ddepartment) {
		this.ddepartment = ddepartment;
	}
	public String getDcon() {
		return dcon;
	}
	public void setDcon(String dcon) {
		this.dcon = dcon;
	}
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPsex() {
		return psex;
	}
	public void setPsex(String psex) {
		this.psex = psex;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPtel() {
		return ptel;
	}
	public void setPtel(String ptel) {
		this.ptel = ptel;
	}
	public String getPpsd() {
		return ppsd;
	}
	public void setPpsd(String ppsd) {
		this.ppsd = ppsd;
	}
	public String getPinfor() {
		return pinfor;
	}
	public void setPinfor(String pinfor) {
		this.pinfor = pinfor;
	}
	public String getPmdad() {
		return pmdad;
	}
	public void setPmdad(String pmdad) {
		this.pmdad = pmdad;
	}
	public int getAnum() {
		return anum;
	}
	public void setAnum(int anum) {
		this.anum = anum;
	}
	public String getYytime() {
		return yytime;
	}
	public void setYytime(String yytime) {
		this.yytime = yytime;
	}
	public String getJztime() {
		return jztime;
	}
	public void setJztime(String jztime) {
		this.jztime = jztime;
	}
	public int getAstate() {
		return astate;
	}
	public void setAstate(int astate) {
		this.astate = astate;
	}
	public int getAtype() {
		return atype;
	}
	public void setAtype(int atype) {
		this.atype = atype;
	}
	public String getDrnum() {
		return drnum;
	}
	public void setDrnum(String drnum) {
		this.drnum = drnum;
	}
	public String getDrname() {
		return drname;
	}
	public void setDrname(String drname) {
		this.drname = drname;
	}
	public float getDrprice() {
		return drprice;
	}
	public void setDrprice(float drprice) {
		this.drprice = drprice;
	}
	public String getDrtype() {
		return drtype;
	}
	public void setDrtype(String drtype) {
		this.drtype = drtype;
	}
	public int getTmnum() {
		return tmnum;
	}
	public void setTmnum(int tmnum) {
		this.tmnum = tmnum;
	}
	public int getDrquantity() {
		return drquantity;
	}
	public void setDrquantity(int drquantity) {
		this.drquantity = drquantity;
	}
	public int getTmstate() {
		return tmstate;
	}
	public void setTmstate(int tmstate) {
		this.tmstate = tmstate;
	}
	public String getMtnum() {
		return mtnum;
	}
	public void setMtnum(String mtnum) {
		this.mtnum = mtnum;
	}
	public String getMtname() {
		return mtname;
	}
	public void setMtname(String mtname) {
		this.mtname = mtname;
	}
	public float getMtprice() {
		return mtprice;
	}
	public void setMtprice(float mtprice) {
		this.mtprice = mtprice;
	}
	public String getMtplace() {
		return mtplace;
	}
	public void setMtplace(String mtplace) {
		this.mtplace = mtplace;
	}
	public int getMtenum() {
		return mtenum;
	}
	public void setMtenum(int mtenum) {
		this.mtenum = mtenum;
	}
	public String getMtetime() {
		return mtetime;
	}
	public void setMtetime(String mtetime) {
		this.mtetime = mtetime;
	}
	public int getMtstate() {
		return mtstate;
	}
	public void setMtstate(int mtstate) {
		this.mtstate = mtstate;
	}
	private int mtstate;
	
	
	
	
	
}

