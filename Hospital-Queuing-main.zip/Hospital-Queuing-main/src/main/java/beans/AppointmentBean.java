package beans;

public class AppointmentBean {
	private int anum;
	private String pnum;
	private String ddepartment;
	private String dnum;
	private String yytime;
	private String jztime;
	private String dcon;
	private int astate;
	private int atype;
	private String pname;
	private String dname;
	private String dtitle;
	
	public int getAnum() {
		return anum;
	}
	public void setAnum(int anum) {
		this.anum = anum;
	}
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getDdepartment() {
		return ddepartment;
	}
	public void setDdepartment(String ddepartment) {
		this.ddepartment = ddepartment;
	}
	public String getDnum() {
		return dnum;
	}
	public void setDnum(String dnum) {
		this.dnum = dnum;
	}
	public String getYytime() {
		return yytime;
	}
	public void setYytime(String yytime) {
		this.yytime = yytime;
	}
	public String getJztime() {
		return jztime;
	}
	public void setJztime(String jztime) {
		this.jztime = jztime;
	}
	public String getDcon() {
		return dcon;
	}
	public void setDcon(String dcon) {
		this.dcon = dcon;
	}
	public int getAstate() {
		return astate;
	}
	public void setAstate(int astate) {
		this.astate = astate;
	}
	public int getAtype() {
		return atype;
	}
	public void setAtype(int atype) {
		this.atype = atype;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDtitle() {
		return dtitle;
	}
	public void setDtitle(String dtitle) {
		this.dtitle = dtitle;
	}
}
