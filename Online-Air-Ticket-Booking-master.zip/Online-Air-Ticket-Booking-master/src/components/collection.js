import React from 'react'
import '../App.css'
function Collection() {
    return (
        <div className='App'>
            <h1>Hii I am Collection Page</h1>
        </div>
    )
}

export default Collection