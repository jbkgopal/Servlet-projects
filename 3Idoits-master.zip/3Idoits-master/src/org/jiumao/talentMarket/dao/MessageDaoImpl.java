package org.jiumao.talentMarket.dao;

import org.jiumao.talentMarket.domain.Message;

import base.BaseDaoImpl;

public class MessageDaoImpl extends BaseDaoImpl<Message> implements MessageDao {

}
