import React from 'react'
import '../style/body.css'
import SearchForm from './SearchForm'
import S from './S'
function Home() {
    
    return (
        <>
           <S/>
           <SearchForm />
        </>
    )
}
export default Home;

