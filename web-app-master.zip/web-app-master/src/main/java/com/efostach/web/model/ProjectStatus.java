package com.efostach.web.model;

public enum ProjectStatus {
    IN_PROGRESS, COMPLETED
}
