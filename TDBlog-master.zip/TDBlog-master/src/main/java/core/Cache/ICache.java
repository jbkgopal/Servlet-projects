package core.Cache;

public interface ICache {
	public void put(CacheItem item);
}
