# Application Info

The App manipulates Employee, Skill, Team, Project entities. All data stored in MySQL database. Each entity has CRUD operations such as GET_ALL, CREATE, UPDATE, DELETE.
To addition to basic CRUD operations, the app support showing filtered projects by cost/skill/team and filtered teams by skill.

## Used technologies

* Servlets + JSP (or Thymeleaf)
* Hibernate
* Liquibase
* MySQL
* Maven
* Travis
* Heroku
