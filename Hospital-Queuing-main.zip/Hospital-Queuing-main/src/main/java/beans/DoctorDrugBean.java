package beans;

public class DoctorDrugBean {
	private int tmnum;
	private String pnum;
	private String drnum;
	private int drquantity;
	private int tmstate;
	public int getTmnum() {
		return tmnum;
	}
	public void setTmnum(int tmnum) {
		this.tmnum = tmnum;
	}
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getDrnum() {
		return drnum;
	}
	public void setDrnum(String drnum) {
		this.drnum = drnum;
	}
	public int getDrquantity() {
		return drquantity;
	}
	public void setDrquantity(int drquantity) {
		this.drquantity = drquantity;
	}
	public int getTmstate() {
		return tmstate;
	}
	public void setTmstate(int tmstate) {
		this.tmstate = tmstate;
	}
	
	
}
