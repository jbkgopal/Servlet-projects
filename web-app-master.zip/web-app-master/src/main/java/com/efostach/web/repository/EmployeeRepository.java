package com.efostach.web.repository;


import com.efostach.web.model.Employee;

public interface EmployeeRepository extends GenericRpository<Employee, Integer> {

}
