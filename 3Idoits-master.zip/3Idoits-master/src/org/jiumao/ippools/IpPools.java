package org.jiumao.ippools;
/**
 * 维护一个在线ip与用户id数据池
 * @author Administrator
 *
 */
public class IpPools {

}
