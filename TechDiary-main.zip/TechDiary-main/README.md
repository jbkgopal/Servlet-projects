# TechDiary Screen Shots

# TechDiary Home:

![1  Tech Diary Home](https://user-images.githubusercontent.com/91146041/208236267-eff8aa23-e61d-4e7d-8927-a3948e8d13b6.png)

# Register:
![2 Register Page](https://user-images.githubusercontent.com/91146041/208236269-4811523d-9240-4304-96bc-f9c4c58deff4.png)

# Login:
![3  Login](https://user-images.githubusercontent.com/91146041/208236271-3971b8ca-7eea-4de5-aa5a-f6b31e1ebc75.png)

# User dashboard:
![4 0 0 User Dash Board](https://user-images.githubusercontent.com/91146041/208236272-a83813bc-33bf-403a-a0c0-5bf1f3a25a4d.png)

# Create Post Page:
![4 0 CreatePost](https://user-images.githubusercontent.com/91146041/208236275-2d88e10a-0a57-4233-8e8f-1b22b28e9025.JPG)

# Post Error:
![4 1  CreatePostError](https://user-images.githubusercontent.com/91146041/208236276-48516f62-a0a9-4caf-9d99-3d7a6b665ec0.JPG)

# Create post details:
![4 2 CreatePostDetails](https://user-images.githubusercontent.com/91146041/208236277-79c73620-1758-4e9c-8754-1765e6e1dbf6.JPG)

# Successfull message aleart:
![4 3  CreatePostSuccessfulMsg](https://user-images.githubusercontent.com/91146041/208236278-1f3872fc-08c9-409c-87c2-ebc3f5647949.JPG)

# All Category:
![5 0 Category wise post](https://user-images.githubusercontent.com/91146041/208236279-ab692ada-1ac0-44de-acac-80fdf34997f2.png)

# No post category:
![5 1 No post in this category](https://user-images.githubusercontent.com/91146041/208236281-c739de24-62e3-40f4-b717-fffce359df4a.png)

# Full Post:
![5 2 ReadMore full post](https://user-images.githubusercontent.com/91146041/208236283-b2278854-4fad-4787-8af1-e44c0c1bf8d9.png)

# Edit User Profile Details:
![6 0 Edit UserProfileDetails](https://user-images.githubusercontent.com/91146041/208236284-8cd5aed7-f537-4df0-a7d9-a50105a42ab7.JPG)

# Update User Profile Details:
![6 1 User Profile Details Update Profile Pic](https://user-images.githubusercontent.com/91146041/208236285-f1d28870-707e-466a-9831-fa320484a4d0.JPG)

# Not Found Resource:
![7 0 404 Not Found](https://user-images.githubusercontent.com/91146041/208236286-0f4fff55-9fe1-41f1-b120-6f9ea0fc722a.png)

# Error:
![7 1 Error Page](https://user-images.githubusercontent.com/91146041/208236287-bd3bb131-35df-495a-9d7f-ba3bee5e47cb.png)

# Thank you!
