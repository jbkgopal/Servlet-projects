package ensiastjob.extra;

public class HomaPathExample {
    //put path of server folder like : C:\xampp\htdocs\ensiastjob\files
    public static final String HOMEPATH = "C:\\";
}
