
function on0(){   
		window.location.href="BackendManage_Main?action=export";		
}

function on1_1(){
	
	   	var no = prompt("请输入你要删除的信息的编号");
   		window.location.href="BackendManage_Main?action=delete&no=" + no + "&num=dnum&table=Doctor";	
}
function on2_1(){
	   	var no = prompt("请输入你要删除的信息的编号");
   		window.location.href="BackendManage_Main?action=delete&no=" + no + "&num=pnum&table=Patient";	
}
function on3_1(){
	   	var no = prompt("请输入你要删除的信息的编号");
   		window.location.href="BackendManage_Main?action=delete&no=" + no + "&num=anum&table=Appointment";	
}
function on4_1(){
	   	var no = prompt("请输入你要删除的信息的编号");
   		window.location.href="BackendManage_Main?action=delete&no=" + no + "&num=drnum&table=Drug";	
}
function on5_1(){
	   	var no = prompt("请输入你要删除的信息的编号");
   		window.location.href="BackendManage_Main?action=delete&no=" + no + "&num=tmnum&table=Take Medicine";	
}
function on6_1(){
	   	var no = prompt("请输入你要删除的信息的编号");
   		window.location.href="BackendManage_Main?action=delete&no=" + no + "&num=mtnum&table=Medical technology";	
}
function on7_1(){
	   	var no = prompt("请输入你要删除的信息的编号");
   		window.location.href="BackendManage_Main?action=delete&no=" + no + "&num=mtenum&table=Medical technology examination";	
}

 function on1_2(){
	 var dropBox = document.getElementById("from1");
     dropBox.style.display = "block";
 }
  function on2_2(){
	 var dropBox = document.getElementById("from2");
     dropBox.style.display = "block";
 }
  function on3_2(){
	 var dropBox = document.getElementById("from3");
     dropBox.style.display = "block";
 }
  function on4_2(){
	 var dropBox = document.getElementById("from4");
     dropBox.style.display = "block";
 }
  function on5_2(){
	 var dropBox = document.getElementById("from5");
     dropBox.style.display = "block";
 }
  function on6_2(){
	 var dropBox = document.getElementById("from6");
     dropBox.style.display = "block";
 }
  function on7_2(){
	 var dropBox = document.getElementById("from7");
     dropBox.style.display = "block";
 }



  function on1_3(){
	 var dropBox = document.getElementById("from1");
     dropBox.style.display = "none";
 }

  function on2_3(){
	 var dropBox = document.getElementById("from2");
     dropBox.style.display = "none";
 }  
  function on3_3(){
	 var dropBox = document.getElementById("from3");
     dropBox.style.display = "none";
 }
  function on4_3(){
	 var dropBox = document.getElementById("from4");
     dropBox.style.display = "none";
 }
  function on5_3(){
	 var dropBox = document.getElementById("from5");
     dropBox.style.display = "none";
 }
  function on6_3(){
	 var dropBox = document.getElementById("from6");
     dropBox.style.display = "none";
 }
  function on7_3(){
	 var dropBox = document.getElementById("from7");
     dropBox.style.display = "none";
 }
 