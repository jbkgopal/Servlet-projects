package ensiastjob.extra;

public class HomePath {
    public static final String HOMEPATH = "C:\\xampp\\htdocs\\ensiastjob\\files";
}
