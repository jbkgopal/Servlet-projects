# MetaCart

[![GitHub issues](https://img.shields.io/github/stars/Vishal1297/MetaCart)](https://github.com/Vishal1297/MetaCart/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/Vishal1297/MetaCart)](https://github.com/Vishal1297/MetaCart/network/members)
[![GitHub Pull Requests](https://img.shields.io/github/issues-pr/Vishal1297/MetaCart?style=plastic)](https://github.com/Vishal1297/MetaCart/pulls)
[![GitHub issues](https://img.shields.io/github/issues/Vishal1297/MetaCart?style=plastic)](https://github.com/Vishal1297/MetaCart/issues)
[![GitHub License](https://img.shields.io/github/license/Vishal1297/MetaCart)](https://github.com/Vishal1297/MetaCart/blob/master/LICENSE)

### A Servlet JSP Shopping Application To Buy Products. :octocat:

## Client Side

<img src="images/MetaCart.png" height="535" width="950"> 
