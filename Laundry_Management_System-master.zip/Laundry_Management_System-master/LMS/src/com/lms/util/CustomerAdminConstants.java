package com.lms.util;

/*
 *  By IT19180526
 */

public class CustomerAdminConstants {


    //Constant for Column index one
    public static final int COLUMN_ONE = 1;

    //Constant for Column index two
    public static final int COLUMN_TWO = 2;

    //Constant for Column index three
    public static final int COLUMN_THREE = 3;

    //Constant for Column index four
    public static final int COLUMN_FOUR = 4;

    //Constant for Column index five
    public static final int COLUMN_FIVE = 5;

    //Constant for Column index six
    public static final int COLUMN_SIX = 6;

    //Constant for Column index seven
    public static final int COLUMN_SEVEN = 7;

    //Constant for Column index eight
    public static final int COLUMN_EIGHT = 8;

}
