# LostProperty
失物招领,失物招领网站,校园失物招领  
Demo：http://47.94.9.151:8080/LostProperty/
>简易的校园失物招领网站  
用户注册 全局搜索 失物发布 留言 后台管理
