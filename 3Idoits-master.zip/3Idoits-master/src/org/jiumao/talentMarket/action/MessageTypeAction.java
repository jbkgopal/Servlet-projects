package org.jiumao.talentMarket.action;

import org.jiumao.talentMarket.domain.MessageType;

import base.BaseAction;

public class MessageTypeAction extends BaseAction<MessageType>{

}
