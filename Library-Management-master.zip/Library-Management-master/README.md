# Library-Management
This project manages overall process of library workflow.

## Technologies
- Servlet
- JSP
- MySql
- JavaScript
