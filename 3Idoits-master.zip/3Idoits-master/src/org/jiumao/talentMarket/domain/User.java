package org.jiumao.talentMarket.domain;

import org.jiumao.login.People;

public class User extends People{



}
