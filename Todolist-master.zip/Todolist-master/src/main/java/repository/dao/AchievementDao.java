package repository.dao;


import model.Achievement;

public interface AchievementDao extends CrudDao<Achievement> {
}
