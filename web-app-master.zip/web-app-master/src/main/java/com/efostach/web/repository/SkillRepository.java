package com.efostach.web.repository;

import com.efostach.web.model.Skill;

public interface SkillRepository extends GenericRpository<Skill, Integer> {

}