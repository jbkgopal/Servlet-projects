package controller;


public interface BeanFactory {
	public Object getBean(String name);
}