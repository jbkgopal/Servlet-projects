package org.jiumao.talentMarket.domain;

import jdbcUtils.QueryHelper;

public class MessageTypeSql extends QueryHelper {

}
