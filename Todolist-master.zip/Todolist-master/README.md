# Todolist application

## Features
- [X] WebServlet, WebFilter, WebListener
- [X] JSP, JSTL
- [X] PostgreSQL
- [X] M2M
- [X] HTML, CSS, JS
- [X] Bootstrap

## Screenshots

<p align="center">
<img src="https://raw.githubusercontent.com/Odenezhkina/Todolist/master/.github/images/Semester1_1.png" />
</p>

<p align="center">
<img src="https://raw.githubusercontent.com/Odenezhkina/Todolist/master/.github/images/Semester_2.png" />
</p>
