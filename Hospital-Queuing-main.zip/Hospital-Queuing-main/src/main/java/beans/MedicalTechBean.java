package beans;

public class MedicalTechBean {
	private int mtenum;
	private String pnum;
	private String mtnum;
	private String mtetime;
	private int mtstate;
	private String pname;
	private String mtname;
	
	public int getMtenum() {
		return mtenum;
	}
	public void setMtenum(int mtenum) {
		this.mtenum = mtenum;
	}
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getMtnum() {
		return mtnum;
	}
	public void setMtnum(String mtnum) {
		this.mtnum = mtnum;
	}
	public String getMtetime() {
		return mtetime;
	}
	public void setMtetime(String mtetime) {
		this.mtetime = mtetime;
	}
	public int getMtstate() {
		return mtstate;
	}
	public void setMtstate(int mtstate) {
		this.mtstate = mtstate;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getMtname() {
		return mtname;
	}
	public void setMtname(String mtname) {
		this.mtname = mtname;
	}
	
	
	
}
