# ENSIAST JOB
ENSIAST Job is a job platform for ENSIAS students, help them find job opportunities or internships. Using various technologies which provide basic tools, for the back-end part of J2EE technology with an MVC architecture and MySQL relational database management system, Javascript, Tailwind CSS, and HTML for the front-end part.
