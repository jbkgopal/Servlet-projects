package ensiastjob.model;

public enum CandidacyStatus {
    Pending,
    Accepted,
    Rejected
}
