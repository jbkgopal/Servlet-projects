package org.jiumao.talentMarket.domain;

import jdbcUtils.QueryHelper;

public class MessageSql extends QueryHelper{
	

}
