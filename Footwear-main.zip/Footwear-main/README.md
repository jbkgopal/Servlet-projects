# Footwear

A ticket raising system is created in this project where user can raise issues using tickets along with the admin dashboard for all the activities in the application integrated with the session tracking of the user in this website.
Java JSPs are used as landing pages & Servlets & Hibernate is used for all the backend Workings.
