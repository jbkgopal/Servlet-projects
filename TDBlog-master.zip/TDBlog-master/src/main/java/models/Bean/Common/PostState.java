package models.Bean.Common;

public enum PostState {
	Pending, 
	Publish,
	Ban
}
