/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gioAlexiou.db2FirstTry;

/**
 *
 * @author gioalexiou
 */
public class BestFiveInRound 
{
    private int rowNumber;
    private String playerName;
    private String playerTeam;
    private String playerNationality;
    private int statistic;

    /**
     * @return the rowNumber
     */
    public int getRowNumber() {
        return rowNumber;
    }

    /**
     * @param rowNumber the rowNumber to set
     */
    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    /**
     * @return the playerName
     */
    public String getPlayerName() {
        return playerName;
    }

    /**
     * @param playerName the playerName to set
     */
    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    /**
     * @return the playerTeam
     */
    public String getPlayerTeam() {
        return playerTeam;
    }

    /**
     * @param playerTeam the playerTeam to set
     */
    public void setPlayerTeam(String playerTeam) {
        this.playerTeam = playerTeam;
    }

    /**
     * @return the playerNationality
     */
    public String getPlayerNationality() {
        return playerNationality;
    }

    /**
     * @param playerNationality the playerNationality to set
     */
    public void setPlayerNationality(String playerNationality) {
        this.playerNationality = playerNationality;
    }

    /**
     * @return the statistic
     */
    public int getStatistic() {
        return statistic;
    }

    /**
     * @param statistic the statistic to set
     */
    public void setStatistic(int statistic) {
        this.statistic = statistic;
    }
    
    
}
