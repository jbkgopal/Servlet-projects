package org.jiumao.talentMarket.dao;

import org.jiumao.talentMarket.domain.MessageType;

import base.BaseDao;

public interface MessageTypeDao extends BaseDao<MessageType> {

}
