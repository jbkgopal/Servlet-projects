# Laundry Management System  

## 2nd Year 1st Semester OOP Project  

## User Interfaces

|  |  |
|--|--|
|<img src="Source/ui/1.png">|<img src="Source/ui/2.png">|
|<img src="Source/ui/3.png">|<img src="Source/ui/4.png">|
|<img src="Source/ui/5.png">|<img src="Source/ui/6.png">|
|<img src="Source/ui/7.png">|<img src="Source/ui/8.png">|
|<img src="Source/ui/9.png">|<img src="Source/ui/10.png">|
|<img src="Source/ui/11.png">|  |  
