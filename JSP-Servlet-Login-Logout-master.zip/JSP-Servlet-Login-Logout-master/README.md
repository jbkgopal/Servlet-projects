# JSP-Servlet-Login-Logout
Simple jsp&amp;servlet login and logout script using session and database using MySQL<br />
***1-Create database&table***<br />
***2-Add 'mysql-connector.jar'  to the lib folder"***
