package models.Bean;

public class Role {
	private String ID;
	private String name;
	
	public String getID() {
		return ID;
	}
	public String getName() {
		return name;
	}
	
	public void setID(String ID) {
		this.ID = ID;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
