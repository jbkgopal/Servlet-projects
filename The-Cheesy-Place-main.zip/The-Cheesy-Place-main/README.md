# The-Cheesy-Place
  A pizza booking website along with the fully functional admin dashboard is completely held with the session tracking of the user.
  
  The teckstacks used in the development of the project is:
  1. Java for all the backend workings.
  2. Servlets & JSPs for the total functionalities.
  3. HTML5/CSS3 and JavaScript for the frontend development.
  4. Eclipse and VSCode frammeworks.
  5. MySQL for the database management of the project data.
