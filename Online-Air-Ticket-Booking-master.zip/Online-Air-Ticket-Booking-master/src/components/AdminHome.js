import React from 'react'

function AdminHome() {
    return (
        <div style={{marginTop:'30px'}}>
            <h2>Welcome</h2>
        </div>
    )
}

export default AdminHome
