package com.efostach.web.repository;

import com.efostach.web.model.Customer;

public interface CustomerRepository extends GenericRpository<Customer, Integer> {

}
