# FileUploadDemo

这是一个关于JavaWeb开发中常用到的文件上传下载的Demo，一般选择采用apache的开源工具common-fileupload这个文件上传组件。这个common-fileupload上传组件的jar包可以去apache官网上面下载，也可以在struts的lib文件夹下面找到，struts上传的功能就是基于这个实现的。common-fileupload是依赖于common-io这个包的。为了方便，可以直接点击这个链接：http://pan.baidu.com/s/1pKQGW2n 密码：lzi6。

参考文档：http://www.cnblogs.com/xdp-gacl/p/4200090.html
